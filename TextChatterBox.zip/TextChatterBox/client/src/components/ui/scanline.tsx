export function Scanline() {
  return <div className="scanline"></div>;
}
